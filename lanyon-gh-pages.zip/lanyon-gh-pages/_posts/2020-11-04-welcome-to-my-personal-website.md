---
layout: post
title: Welcome to my personal website!
author: Keelan Cook

---

Hey there! You’ve stumbled upon my personal website. You can find my professional site here: [Peoples Next Door](http://keelancook.com). 

This site is the result of a couple of desires. First, I've been wanting an online home apart from my professional site. The purpose of the Peoples Next Door is narrow, and I use it to provides helps to the church. It's not the place for off topic posts or to simply lean back and put my feet up. I hope that this can serve in that regard while also being a place that functions as an online profile of sorts. Here, you can find my curriculum vitae as well as a sample of the projects about which I am most excited. These projects may be work related or of some other manner entirely.

In addition, I’m attempting to learn more about building my own websites with Jekyll. This site is hosted on my own Github repository. It is a free, relatively secure means of building your own website. I've been intrigued by the use of static websites and markdown for content management for a while now, and though I don't know much about it, I finally figured out enough to give it a stab on my own.
<!--stackedit_data:
eyJoaXN0b3J5IjpbMjA5NDA4OTQ2MSwtMTU5MzIyNzA4NCwyMD
k0MDg5NDYxXX0=
-->