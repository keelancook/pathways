---
layout: page
title: Book Notes (Coming soon!)

---

> **Work in Progress:**
> I'm still working to build out the book notes section. I am really excited about providing this, though, so check back soon and hopefully this will be functional!

These book notes are an ongoing experiment. I've been blessed to do a great deal of study and research in life, a benefit I know not all share. I've gained great insight into faith and practice from others.

{% include archive.html %}
<!--stackedit_data:
eyJoaXN0b3J5IjpbMTM5ODY3Nzg4MCw1NzIzNDg4NiwtNDkyMz
MyNTE2LDE1MDUyODIzNCwxNzQ1OTUxNzczLDE2NjY5Mjk3OTVd
fQ==
-->